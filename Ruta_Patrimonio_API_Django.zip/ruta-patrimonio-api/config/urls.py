"""Rutas principales: panel administrativo y API versionada por prefijo."""
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("patrimonio.urls")),
]
